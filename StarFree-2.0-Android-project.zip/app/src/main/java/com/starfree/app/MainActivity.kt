package com.starfree.app

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 8, 18)
    private val surface = Color.rgb(24, 21, 38)
    private val surface2 = Color.rgb(35, 30, 53)
    private val purple = Color.rgb(197, 166, 255)
    private val text = Color.rgb(246, 243, 252)
    private val muted = Color.rgb(165, 158, 183)
    private lateinit var query: EditText
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var historyBox: LinearLayout
    private lateinit var favoritesBox: LinearLayout
    private var currentTab = "search"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(12))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val brand = TextView(this).apply {
            text = "✦  STARFREE"
            textSize = 21f
            letterSpacing = .13f
            setTextColor(text)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val version = TextView(this).apply {
            text = "2.0"
            textSize = 11f
            setTextColor(purple)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(surface2, 30)
        }
        top.addView(version)
        page.addView(top)

        val hero = TextView(this).apply {
            text = "Находи открытые публикации"
            textSize = 25f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(text)
            setPadding(0, dp(28), 0, dp(5))
        }
        page.addView(hero)
        val sub = TextView(this).apply {
            text = "Поиск публичных копий и репостов — без обхода платного доступа."
            textSize = 13f
            setTextColor(muted)
        }
        page.addView(sub)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(22), 0, dp(18))
        }
        tabs.addView(tab("Поиск", "search"), LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(tab("История", "history"), LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(7) })
        tabs.addView(tab("Избранное", "favorites"), LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(7) })
        page.addView(tabs)

        if (currentTab == "search") {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(16), dp(16), dp(16))
                background = rounded(surface, 20)
            }
            card.addView(label("ССЫЛКА, НАЗВАНИЕ ИЛИ КЛЮЧЕВЫЕ СЛОВА"))
            query = EditText(this).apply {
                hint = "Например: https://t.me/channel/123"
                setHintTextColor(muted)
                setTextColor(text)
                textSize = 14f
                singleLine = false
                minLines = 2
                maxLines = 3
                gravity = Gravity.TOP
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(surface2, 12)
            }
            card.addView(query, LinearLayout.LayoutParams(-1, dp(82)).apply { topMargin = dp(10) })

            val searchBtn = button("НАЙТИ ПУБЛИЧНЫЕ КОПИИ", true) { doSearch() }
            card.addView(searchBtn, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(button("В избранное ☆", false) { saveFavorite() }, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(button("Открыть Telegram", false) { openTelegram() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })
            card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            page.addView(card)

            status = TextView(this).apply {
                text = "Совет: вставь ссылку на пост или введи название канала."
                textSize = 12f
                setTextColor(muted)
                setPadding(dp(4), dp(14), dp(4), dp(4))
            }
            page.addView(status)
            results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            page.addView(results)
        } else if (currentTab == "history") {
            page.addView(sectionTitle("Последние запросы"))
            historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            page.addView(historyBox)
            loadList(historyBox, "history")
            page.addView(button("Очистить историю", false) { clearList("history"); loadList(historyBox, "history") })
        } else {
            page.addView(sectionTitle("Сохранённые запросы"))
            favoritesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            page.addView(favoritesBox)
            loadList(favoritesBox, "favorites")
        }

        val footer = TextView(this).apply {
            text = "STARFREE  •  ОТКРЫТЫЙ КОНТЕНТ"
            textSize = 10f
            letterSpacing = .12f
            setTextColor(Color.rgb(103, 96, 124))
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(16))
        }
        page.addView(footer)
        scroll.addView(page)
        root.addView(scroll)
        setContentView(root)
    }

    private fun tab(title: String, key: String): TextView = TextView(this).apply {
        text = title
        gravity = Gravity.CENTER
        textSize = 12f
        setTextColor(if (currentTab == key) Color.rgb(20, 15, 30) else muted)
        background = rounded(if (currentTab == key) purple else surface, 12)
        setOnClickListener { currentTab = key; render() }
    }

    private fun doSearch() {
        val q = query.text.toString().trim()
        if (q.isEmpty()) {
            query.error = "Введи ссылку или поисковый запрос"
            return
        }
        saveTo("history", q)
        hideKeyboard()
        status.text = "Открываю поиск по открытым источникам…"
        val encoded = Uri.encode("\"$q\" Telegram")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded"))
        startActivity(intent)
    }

    private fun saveFavorite() {
        val q = query.text.toString().trim()
        if (q.isEmpty()) {
            query.error = "Сначала введи ссылку или запрос"
            return
        }
        saveTo("favorites", q)
        status.text = "Добавлено в избранное ☆"
    }

    private fun openTelegram() {
        val raw = query.text.toString().trim()
        if (raw.isEmpty()) { query.error = "Вставь ссылку на Telegram"; return }
        val uri = Uri.parse(raw)
        if (uri.scheme !in listOf("http", "https") || !(uri.host ?: "").endsWith("t.me")) {
            query.error = "Нужна ссылка вида https://t.me/..."
            return
        }
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun saveTo(key: String, value: String) {
        val prefs = getSharedPreferences("starfree", Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(key, "[]"))
        val fresh = JSONArray()
        fresh.put(value)
        for (i in 0 until arr.length()) {
            val old = arr.optString(i)
            if (old != value && fresh.length() < 30) fresh.put(old)
        }
        prefs.edit().putString(key, fresh.toString()).apply()
    }

    private fun loadList(box: LinearLayout, key: String) {
        box.removeAllViews()
        val arr = JSONArray(getSharedPreferences("starfree", 0).getString(key, "[]"))
        if (arr.length() == 0) {
            box.addView(TextView(this).apply {
                text = "Пока здесь пусто."
                setTextColor(muted)
                textSize = 13f
                setPadding(0, dp(12), 0, dp(12))
            })
            return
        }
        for (i in 0 until arr.length()) {
            val value = arr.optString(i)
            val item = TextView(this).apply {
                text = "↗  $value"
                textSize = 13f
                setTextColor(text)
                setPadding(dp(13), dp(14), dp(13), dp(14))
                background = rounded(surface, 12)
                setOnClickListener {
                    currentTab = "search"
                    render()
                    query.setText(value)
                }
            }
            box.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
    }

    private fun clearList(key: String) {
        getSharedPreferences("starfree", 0).edit().remove(key).apply()
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 10f
        letterSpacing = .07f
        setTextColor(purple)
    }

    private fun sectionTitle(s: String) = TextView(this).apply {
        text = s
        textSize = 19f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(text)
        setPadding(0, dp(8), 0, dp(15))
    }

    private fun button(title: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        text = title
        textSize = 12f
        isAllCaps = false
        setTextColor(if (primary) Color.rgb(19, 14, 29) else text)
        background = rounded(if (primary) purple else surface2, 13)
        setOnClickListener { action() }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
